function showWarehouses() {
    var product = document.getElementById("product").value;
    if (product == "Select") {
      document.getElementById("warehouseList").innerHTML = 
        "<select id='warehouse'>" +
        "<option value='Warehouse A'>-</option>" +
        "</select>";
        }
    else if (product == "Product 1") {
      document.getElementById("warehouseList").innerHTML = 
        "<select id='warehouse'>" +
        "<option value='Warehouse A'>Warehouse A</option>" +
        "<option value='Warehouse B'>Warehouse B</option>" +
        "</select>";
    } else if (product == "Product 2") {
      document.getElementById("warehouseList").innerHTML = 
        "<select id='warehouse'>" +
        "<option value='Warehouse C'>Warehouse C</option>" +
        "<option value='Warehouse D'>Warehouse D</option>" +
        "</select>";
    }
}