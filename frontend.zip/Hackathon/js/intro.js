document.getElementById("login").addEventListener("click", function() {
    window.location.href = "login/login.html";
});