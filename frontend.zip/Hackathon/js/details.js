var form = document.querySelector("form");
form.addEventListener("submit", function(event) {
    event.preventDefault();
    var name = document.getElementById("name").value;
    var country = document.getElementById("country").value;
    var capacity = document.getElementById("capacity").value;
    // validate form data
    if (name === "" || country === "" || capacity === "") {
        alert("Please fill in all fields");
        return;
    }
    // send form data to the server
    // ...
});