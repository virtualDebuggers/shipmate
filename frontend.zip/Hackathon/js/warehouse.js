var countries = ["Afghanistan", "Albania", "Algeria", "Andorra", "Angola"];
var countriesList = document.getElementById("countries");
for (var i = 0; i < countries.length; i++) {
    var country = document.createElement("a");
    country.innerHTML = countries[i];
    country.href = "country.html?name=" + countries[i];
    country.target = "_blank";
    countriesList.appendChild(country);
    var br = document.createElement("br");
    countriesList.appendChild(br);
}

var username = "John Doe";
document.getElementById("username").innerHTML = username;

var redirectButton = document.getElementById("details");
redirectButton.addEventListener("click", function() {
    window.location.assign = "details.html";
});