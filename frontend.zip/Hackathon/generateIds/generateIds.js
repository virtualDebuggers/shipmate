const generateBtn = document.getElementById("generate-btn");
const trackingNumber = document.getElementById("tracking-number");

generateBtn.addEventListener("click", function () {
    const uniqueId = Math.random().toString(36).substr(2, 9);
    trackingNumber.value = uniqueId;
});