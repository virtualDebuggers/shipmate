function trackShipment() {
    var trackingId = document.getElementById("tracking-id").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        document.getElementById("status").innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "getStatus.php?trackingId=" + trackingId, true);
    xhttp.send();
  }

/*Note: This is a basic example, you need to replace the getStatus.php to your own endpoint. Also you can use any library like jQuery or Axios for ajax call instead of XMLHttpRequest.*/